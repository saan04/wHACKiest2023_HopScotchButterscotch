function collect(){
let usn= document.getElementById("usn").value;
let dob= document.getElementById("dob").value;
window.alert(usn,dob)
}